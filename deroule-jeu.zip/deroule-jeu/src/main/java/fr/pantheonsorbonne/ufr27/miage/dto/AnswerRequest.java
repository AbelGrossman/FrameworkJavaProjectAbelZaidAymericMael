package fr.pantheonsorbonne.ufr27.miage.dto;

public class AnswerRequest {
    private String playerId;
    private String answer;

    // Getters and Setters

    public String getPlayerId() {
        return playerId;
    }

    public void setPlayerId(String playerId) {
        this.playerId = playerId;
    }

    public String getAnswer() {
        return answer;
    }

    public void setAnswer(String answer) {
        this.answer = answer;
    }
}