package fr.pantheonsorbonne.ufr27.miage.model;

import java.util.List;

public class Leaderboard {

    private List<Player> rankings;

    public Leaderboard(List<Player> rankings) {
        this.rankings = rankings;
    }

    // Getters and Setters
    public List<Player> getRankings() {
        return rankings;
    }

    public void setRankings(List<Player> rankings) {
        this.rankings = rankings;
    }
}

