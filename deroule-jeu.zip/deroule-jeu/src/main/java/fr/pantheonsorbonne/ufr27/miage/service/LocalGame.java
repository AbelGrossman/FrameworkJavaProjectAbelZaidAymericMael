package fr.pantheonsorbonne.ufr27.miage.service;

import fr.pantheonsorbonne.ufr27.miage.dto.QuestionDTO;
import fr.pantheonsorbonne.ufr27.miage.model.Player;
import jakarta.enterprise.context.ApplicationScoped;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

@ApplicationScoped
public class LocalGame {

    private static final Logger logger = LoggerFactory.getLogger(LocalGame.class);
    private ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);
    private List<QuestionDTO> questions;
    private List<Player> players;
    private int currentQuestionIndex = 0;

    public void startGame(List<QuestionDTO> questions, List<Player> players) {
        if (questions == null || questions.isEmpty()) {
            throw new IllegalArgumentException("Questions cannot be null or empty.");
        }
        if (players == null || players.isEmpty()) {
            throw new IllegalArgumentException("Players cannot be null or empty.");
        }

        this.questions = questions;
        this.players = players;
        logger.info("Game started with {} questions.", questions.size());

        scheduler.scheduleAtFixedRate(this::displayNextQuestion, 0, 10, TimeUnit.SECONDS);
    }

    private void displayNextQuestion() {
        if (currentQuestionIndex < questions.size()) {
            QuestionDTO currentQuestion = questions.get(currentQuestionIndex);
            logger.info("Displaying question {}: {}", currentQuestionIndex + 1, currentQuestion.getQuestion());
            // Notify all interfaces to display the current question
            notifyInterfaces(currentQuestion);
            currentQuestionIndex++;
        } else {
            logger.info("Game Over!");
            scheduler.shutdown();
            displayFinalScores();
        }
    }

    private void notifyInterfaces(QuestionDTO question) {
        // Implement logic to notify all interfaces to display the current question
        // This could involve sending a message to all connected clients or updating a shared state
        // For simplicity, we'll just log the notification
        logger.info("Notifying interfaces to display question: {}", question.getQuestion());
    }

    public void processAnswer(String playerId, String answer) {
        if (currentQuestionIndex < questions.size()) {
            QuestionDTO currentQuestion = questions.get(currentQuestionIndex);
            boolean isCorrect = checkAnswer(answer, currentQuestion);
            Player player = getPlayerById(playerId);
            if (player != null) {
                if (isCorrect) {
                    player.setScore(player.getScore() + 1);
                    logger.info("Player {} answered correctly: {}", playerId, answer);
                } else {
                    logger.info("Player {} answered incorrectly: {}", playerId, answer);
                }
            } else {
                logger.error("Player not found with ID: {}", playerId);
            }
        } else {
            logger.error("No current question to process answer for player: {}", playerId);
        }
    }

    private boolean checkAnswer(String answer, QuestionDTO question) {
        return question.getCorrect_answer().equals(answer);
    }

    private Player getPlayerById(String playerId) {
        for (Player player : players) {
            if (player.getId().equals(playerId)) {
                return player;
            }
        }
        return null;
    }

    private void displayFinalScores() {
        logger.info("Final Scores:");
        for (Player player : players) {
            logger.info("Player {} - Score: {}", player.getId(), player.getScore());
        }
    }

    public void finishGame() {
        logger.info("Game finished. Final scores will be displayed.");
        displayFinalScores();
    }
}